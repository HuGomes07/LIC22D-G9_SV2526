library ieee;
use ieee.std_logic_1164.all;

entity Decoder is
	port(
		S:  in  std_logic_vector(1 downto 0);
		E:  in  std_logic;
		O:  out std_logic_vector(3 downto 0)
	);
end Decoder;

architecture structural of Decoder is

component DeMUX is
	port(
		Y: in  std_logic;
		E: in  std_logic;
		S: in  std_logic;
		O: out std_logic_vector(1 downto 0)
	);
end component DeMUX;

signal Outs : std_logic_vector(1 downto 0);

begin
	DeMUX1: DeMUX port map(Y => '1'    , E => E, S => S(1), O    => Outs);
	DeMUX2: DeMUX port map(Y => Outs(0), E => E, S => S(0), O(0) => O(0), O(1) => O(1));
	DeMUX3: DeMUX port map(Y => Outs(1), E => E, S => S(0), O(0) => O(2), O(1) => O(3));
end structural;