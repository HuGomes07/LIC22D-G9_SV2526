// Versão simplificada do TUI, que lê valores do teclado (KBD) e os imprime no LCD.
// Esta versão não faz shift dos dados da linha de baixo para a de cima, caso todo o LCD fique preenchido.
fun main() {
    LCD.init()
    var currCol = 0
    var currLine = 0
    while (true){
        if (HAL.isBit(kValMask)){
            Time.sleep(50)
            val k = KBD.getKey()
            LCD.write(k)
            println(k)
            currCol++
            HAL.setBits(k_ack)
            while(HAL.isBit(kValMask));
            Time.sleep(100)
            HAL.clrBits(k_ack)
            if(currCol == LCD.COLS) {
                currCol = 0
                if(currLine++ < LCD.LINES) currLine++
                else currLine = 0
                LCD.cursor(currLine, currCol)
            }
        }
    }
}